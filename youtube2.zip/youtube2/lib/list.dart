class Video {
  final String name, title, im;

  Video({
    required this.name,
    required this.title,
    required this.im,
  });

}
List videoData = [
  Video(
    name: 'iduMlQtLeo0',
    title: 'Что такое PPF Power Gel',
    im: 'https://s786sas.storage.yandex.net/rdisk/c6f50088ae84b6048fd3c56c20d2e266b44e9c49a581fbdf1a1ed3ac91f66c58/63e2d5af/Gg-y-KiN2UdO28f1oIz6bVArGvpWaWoJW1L1pLvhEZgNv0qDSz_Qz-B-b5vJUa21IfwWoxkxsMBoK86yASEbUQ==?uid=1576227987&filename=2023-02-07_20-54-58.png&disposition=inline&hash=&limit=0&content_type=image%2Fpng&owner_uid=1576227987&fsize=2838956&hid=aa8e234566463062ee08b92a2cd6067c&media_type=image&tknv=v2&etag=0d1bce8f761c83c3184dbeac83664e15&rtoken=5blMC3HJ24vt&force_default=yes&ycrid=na-cc63b3499bd2c64636f8829a8179f822-downloader16h&ts=5f423f90d89c0&s=02e422dc940e28ae3fae69eb614d59d0d7691cfb237123762fef2a963f2aaac3&pb=U2FsdGVkX1-ikOhCQE1cRzAbjqiFUX7Xz1A3-7N4_Sijo_8mC-JEzdORZn-PTRPsl8NeNWzqwnNGyZMDLMIKLjvHMFAopv_5FeSEa0BI36I',

  ),
  Video(
    name: 'JfnWs2vb4mg',
    title: 'Работа с PPF Power Gel',
    im: 'https://i9.ytimg.com/vi_webp/JfnWs2vb4mg/mq2.webp?sqp=CIDViJ8G&rs=AOn4CLBjpP-LF82vmw-b-FDTvnc4Pftr3A',

  ),
  Video(
    name: 'dhAMD9i8vmQ',
    title: 'Оклейка заднего крыла на Lamborghini Huracan',
    im: 'https://i9.ytimg.com/vi_webp/dhAMD9i8vmQ/mq2.webp?sqp=CIDViJ8G&rs=AOn4CLCpHA469gn3wa13KzqYP-cdvvrojg',

  ),
  Video(
    name: 'rxzGfwCzTm8',
    title: 'Как оклеить чашечку под ручкой на Porsche Cayenne',
    im: 'https://i9.ytimg.com/vi_webp/rxzGfwCzTm8/mq1.webp?sqp=CIDViJ8G&rs=AOn4CLCwUI9S60hE89AWPhL0XLeOeOjABw&retry=1',


  ),
  Video(
    name: 'F4SSJe43dbY',
    title: 'Углубление крыла под фару на Porsche 911 turbo s',
    im: 'https://i9.ytimg.com/vi_webp/F4SSJe43dbY/mq1.webp?sqp=CKzXiJ8G-oaymwEmCMACELQB8quKqQMa8AEB-AH-CYAC0AWKAgwIABABGBMgNSh_MA8=&rs=AOn4CLDKz5YfEOODCZoqj9cu1ZYd5NlHsA',

  ),
  Video(
    name: 'FAu2Trpdt2o',
    title: 'Оклейка переднего крыла Porsche 911 turbo s',
    im: 'https://i9.ytimg.com/vi_webp/FAu2Trpdt2o/mq1.webp?sqp=CKzXiJ8G-oaymwEmCMACELQB8quKqQMa8AEB-AH-CYAC0AWKAgwIABABGGUgXyhTMA8=&rs=AOn4CLD0VXII-cuVvgU4SDbrufoQX2NRSA',

  ),
  Video(
    name: '_YLEDRFy7SU',
    title: 'Заворот пленки на углах без натяжения',
    im: 'https://i9.ytimg.com/vi_webp/_YLEDRFy7SU/mq1.webp?sqp=CKzXiJ8G-oaymwEmCMACELQB8quKqQMa8AEB-AH-CYAC0AWKAgwIABABGGUgYShOMA8=&rs=AOn4CLDH8MOO5CEVY0ZXoXbjnDCPWoYtiA',

  ),
  Video(
    name: 'Qs5bimu9tzk',
    title: 'Заворот пленки на острых углах без натяжения',
    im: 'https://i9.ytimg.com/vi_webp/Qs5bimu9tzk/mq2.webp?sqp=CKzXiJ8G-oaymwEmCMACELQB8quKqQMa8AEB-AH-CYAC0AWKAgwIABABGBMgMyh_MA8=&rs=AOn4CLAb7usho26mpQqUchuFzDpB_k8Wkw',

  ),


];