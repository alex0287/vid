import 'dart:developer';

import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:youtube2/style/style.dart';
import 'package:youtube_player_flutter/youtube_player_flutter.dart';
import 'list.dart';
import 'video_list.dart';


/// Homepage
class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key});

  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  late YoutubePlayerController _controller;
  late TextEditingController _idController;
  late TextEditingController _seekToController;

  late PlayerState _playerState;
  late YoutubeMetaData _videoMetaData;
  double _volume = 100;
  bool _muted = false;
  bool _isPlayerReady = false;

  final List<String> _ids = [
    'iduMlQtLeo0',
    'JfnWs2vb4mg',
    'dhAMD9i8vmQ',
    'rxzGfwCzTm8',
    'F4SSJe43dbY',
    'FAu2Trpdt2o',
    '_YLEDRFy7SU',
    'Qs5bimu9tzk',

  ];

  void initFirebase() async {
    WidgetsFlutterBinding.ensureInitialized();
    await Firebase.initializeApp();
  }


  @override
  void initState() {
    super.initState();
    initFirebase();
    _controller = YoutubePlayerController(
      initialVideoId: _ids.first,
      flags: const YoutubePlayerFlags(
        mute: false,
        autoPlay: true,
        disableDragSeek: false,
        loop: false,
        isLive: false,
        forceHD: false,
        enableCaption: true,
      ),
    )..addListener(listener);
    _idController = TextEditingController();
    _seekToController = TextEditingController();
    _videoMetaData = const YoutubeMetaData();
    _playerState = PlayerState.unknown;
  }

  void listener() {
    if (_isPlayerReady && mounted && !_controller.value.isFullScreen) {
      setState(() {
        _playerState = _controller.value.playerState;
        _videoMetaData = _controller.metadata;
      });
    }
  }

  @override
  void deactivate() {
    // Pauses video while navigating to next page.
    _controller.pause();
    super.deactivate();
  }

  @override
  void dispose() {
    _controller.dispose();
    _idController.dispose();
    _seekToController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return YoutubePlayerBuilder(
      onExitFullScreen: () {
        // The player forces portraitUp after exiting fullscreen. This overrides the behaviour.
        SystemChrome.setPreferredOrientations(DeviceOrientation.values);
      },
      player: YoutubePlayer(
        controller: _controller,
        showVideoProgressIndicator: true,
        progressIndicatorColor: col2,
        topActions: <Widget>[
          const SizedBox(width: 8.0),
          Expanded(
            child: Text(
              _controller.metadata.title,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 18.0,
              ),
              overflow: TextOverflow.ellipsis,
              maxLines: 1,
            ),
          ),
          IconButton(
            icon: const Icon(
              Icons.settings,
              color: Colors.white,
              size: 25.0,
            ),
            onPressed: () {
              log('Settings Tapped!');
            },
          ),
        ],
        onReady: () {
          _isPlayerReady = true;
        },
        onEnded: (data) {
          _controller
              .load(_ids[(_ids.indexOf(data.videoId) + 1) % _ids.length]);
        },
      ),
      builder: (context, player) => Scaffold(
        backgroundColor: col4,
        appBar: AppBar(
          backgroundColor: col5,
          leading: Container(
            margin: EdgeInsets.only(left: 10),
            height: 30,
            width: 60,
            child: Image(image: AssetImage('assets/logo.png')),
          ),
          title: const Text(
            'RWS',
            style: TextStyle(color: Colors.white),
          ),
           // actions: [
           //   IconButton(
           //     icon: const Icon(Icons.video_library),
           //     onPressed: () => Navigator.push(
           //       context,
           //       CupertinoPageRoute(
           //         builder: (context) => VideoList(),
           //       ),
           //     ),
           //   ),
           // ],
        ),
        body: CustomScrollView(
          slivers: [
            SliverAppBar(
              pinned: false,
              snap: true,
              floating: true,
              backgroundColor: col4,
              expandedHeight: 300,
              flexibleSpace: FlexibleSpaceBar(
                background: ListView(
                  children: [
                    player,
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        const SizedBox(
                          height: 10,
                        ),
                        Padding(
                          padding: const EdgeInsets.only(left:8.0),
                          child: Text(_videoMetaData.title, style: const TextStyle(color: col3),),
                        ),
                        _space,
                        //СТРОКА ПЛЕЕРА
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          children: [
                            IconButton(
                              icon: const Icon(Icons.skip_previous, color: col3, size: 20,),
                              onPressed: _isPlayerReady
                                  ? () => _controller.load(_ids[
                              (_ids.indexOf(_controller.metadata.videoId) -
                                  1) %
                                  _ids.length])
                                  : null,
                            ),
                            IconButton(
                              icon: Icon(
                                _controller.value.isPlaying
                                    ? Icons.pause
                                    : Icons.play_arrow,
                                color: col3, size: 20,

                              ),
                              onPressed: _isPlayerReady
                                  ? () {
                                _controller.value.isPlaying
                                    ? _controller.pause()
                                    : _controller.play();
                                setState(() {});
                              }
                                  : null,
                            ),
                            IconButton(
                              icon: Icon(_muted ? Icons.volume_off : Icons.volume_up, color: col3, size: 20,),
                              onPressed: _isPlayerReady
                                  ? () {
                                _muted
                                    ? _controller.unMute()
                                    : _controller.mute();
                                setState(() {
                                  _muted = !_muted;
                                });
                              }
                                  : null,
                            ),

                            IconButton(
                              icon: const Icon(Icons.skip_next, color: col3, size: 20,),
                              onPressed: _isPlayerReady ? () => _controller.load(_ids[
                              (_ids.indexOf(_controller.metadata.videoId) +
                                  1) %
                                  _ids.length])
                                  : null,
                            ),
                            // Slider(
                            //   secondaryActiveColor: col3,
                            //   activeColor: col2,
                            //   inactiveColor: Colors.white12,
                            //   value: _volume,
                            //   min: 0.0,
                            //   max: 100.0,
                            //   divisions: 20,
                            //   label: '${(_volume).round()}',
                            //   onChanged: _isPlayerReady
                            //       ? (value) {
                            //     setState(() {
                            //       _volume = value;
                            //     });
                            //     _controller.setVolume(_volume.round());
                            //   }
                            //       : null,
                            // ),
                          ],
                        ),
                        _space,
                        //ГРОМКОСТЬ

                      ],
                    ),
                  ],
                ),
              ),
            ),
            SliverList(delegate: SliverChildListDelegate([
              Container(
                height: 430,
                child: ListView.builder(
                    itemCount: videoData.length,
                    itemBuilder: (context, index) => Row(
                      children: [
                        Container(
                            margin: const EdgeInsets.all(10),
                            height: 110,
                            width: 190,
                            child: Stack(
                              alignment: AlignmentDirectional.center,
                              children: [
                                Image(image: NetworkImage(videoData[index].im,),),
                                TextButton(
                                    onPressed: _isPlayerReady ? () =>
                                        _controller.load(_ids[
                                        (_ids.indexOf(videoData[index].name))
                                            % _ids.length])
                                        : null,
                                    child: const Text('',style:  TextStyle(color: col3)
                                    )
                                ),
                              ],
                            )
                        ),
                        Flexible(
                            child: Text(videoData[index].title, style: const TextStyle(color: col3),)
                        )
                      ],
                    )
                ),
              )
            ]))

          ],
        )
      ),
    );
  }

  Widget _text(String title, String value) {
    return RichText(
      text: TextSpan(
        style: const TextStyle(
          color: col3,
          fontWeight: FontWeight.bold,
        ),
        children: [
          TextSpan(
            text: value,
            style: const TextStyle(
              color: col3,
              fontWeight: FontWeight.w300,
            ),
          ),
        ],
      ),
    );
  }



  Widget get _space => const SizedBox(height: 2);
  Widget get _space2 => const SizedBox(height: 5);

}