import 'package:flutter/material.dart';
import 'package:youtube_player_flutter/youtube_player_flutter.dart';

Color _getStateColor(PlayerState state) {
  switch (state) {
    case PlayerState.unknown:
      return Colors.grey[700]!;
    case PlayerState.unStarted:
      return Colors.pink;
    case PlayerState.ended:
      return Colors.red;
    case PlayerState.playing:
      return Colors.blueAccent;
    case PlayerState.paused:
      return Colors.orange;
    case PlayerState.buffering:
      return Colors.yellow;
    case PlayerState.cued:
      return Colors.blue[900]!;
    default:
      return Colors.red;
  }
}
const col2 = Color(0xFF1E4F86);

const col3 = Color(0xFFDADADA);
const col4 = Color(0xFF0D0D10);
const col5 = Color(0xFF1B0F26);
